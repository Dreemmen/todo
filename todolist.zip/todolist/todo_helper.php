<?php
define("asdasdeq1312","fdgkpeitper");
$debug_mode = true;// true - atkļūdošanas režīms ieslēgts
if($debug_mode){
    error_reporting(E_ALL);
}
session_start();

require_once "db_connect.php"; // $mysqli objekts atrodas šeit
require_once "class_todo.php";

$result = $mysqli->query("SELECT `user_id` as id FROM `users` WHERE `identifier` = 'test_user'; ");
$user_id = $result->fetch_object()->id;
$todo_class = new todo($mysqli, $user_id, $debug_mode);

//izveido jaunu pozīciju todo sarakstā
if(isset($_POST['submit_add_todo'])){
    $todo_title = htmlspecialchars(stripslashes($_POST['todo_title']));
    $todo_text = htmlspecialchars(stripslashes($_POST['todo_text']));
    if(!empty($todo_title)){
        $todo_class->create($todo_title, $todo_text);
    }
    if($debug_mode){
        $_SESSION['last_todo']['title'] = $todo_title;
        $_SESSION['last_todo']['text'] = $todo_text;
        $_SESSION['last_todo']['id'] = '';
    }
}
if(isset($_POST['submit_edit_todo'])){
    $todo_title = htmlspecialchars(stripslashes($_POST['todo_title']));
    $todo_text = htmlspecialchars(stripslashes($_POST['todo_text']));
    $todo_id = (int) $_POST['todo_id'];
    $todo_class->update($todo_title, $todo_text, $todo_id);
    if($debug_mode){
        $_SESSION['last_todo']['title'] = $todo_title;
        $_SESSION['last_todo']['text'] = $todo_text;
        $_SESSION['last_todo']['id'] = $todo_id;
    }
}
if(isset($_GET['delete'])){
    $todo_id = (int) $_GET['id'];
    $todo_class->delete($todo_id);
}
if(isset($_GET['reorder'])){
    $todo_id = (int) $_GET['id'];
    if($_GET['reorder']=='up' || $_GET['reorder']=='down'){
        $todo_class->reorder($todo_id, $_GET['reorder']);
    }
}
header("Location: ".$_SERVER['HTTP_REFERER']);
die();
?>
