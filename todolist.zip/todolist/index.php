<?php
define("asdasdeq1312","fdgkpeitper");
$debug_mode = true;// true - atkļūdošanas režīms ieslēgts
if($debug_mode){
    error_reporting(E_ALL);
}
session_start();
$mysqli = '';
$user_id = '';

require_once "db_connect.php"; // $mysqli objekts atrodas šeit
require_once "class_todo.php";

//ID tiek iegūs no unikālas vērtības, ko nezin pat lietotājs (parasti lietotajvārds + parole)
$result = $mysqli->query("SELECT `user_id` as id FROM `users` WHERE `identifier` = 'test_user'; ");
$user_id = $result->fetch_object()->id;
$todo_class = new todo($mysqli, $user_id, $debug_mode);
?>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="site.css" />

  <title>Todo list example</title>
</head>
<body>
    <div id="popup_add" class="popup" style="display: none;">
        <div class="content">
            <h1 class="title">Pievienot jaunu pozīciju</h1>
            <form name="f_add_todo" id="f_add_todo" method="post" action="todo_helper.php">
                <div class="todo_title">Virsraksts:</div>
                <textarea rows="4" cols="50" name="todo_title"></textarea></br>
                <div class="todo_text">Apraksts:</div>
                <textarea rows="4" cols="50" name="todo_text"></textarea></br>
                <input type="button" onclick="hide_add_popup();" value="Doties atpakaļ">
                <input type="submit" name="submit_add_todo" value="Pievienot">
            </form>
        </div>
    </div>
    <div id="popup_edit" class="popup" style="display: none;">
        <div class="content">
            <h1 class="title">Labot vai dzēst</h1>
            <form name="f_add_todo" id="f_edit_todo" method="post" action="todo_helper.php">
                <div class="todo_title">Virsraksts:</div>
                <textarea rows="4" cols="50" id="f_edit_todo_title" name="todo_title"></textarea></br>
                <div class="todo_text">Apraksts:</div>
                <textarea rows="4" cols="50" id="f_edit_todo_text" name="todo_text"></textarea></br>
                <input type="hidden"  id="f_edit_todo_id" name="todo_id" value="">
                <input type="button" onclick="hide_edit_popup();" value="Doties atpakaļ">
                <input type="button" onclick="delete_edit_popup();" value="Dzēst">
                <input type="submit" name="submit_edit_todo" value="Saglabāt">
            </form>
        </div>
    </div>

    <div class="website_wrapper">
        <div class="heading">
            <h1>Darāmo lietu saraksts<h1>
        </div>
        <div class="todo" id="todo">
            <div class="add_new_item">
                <div class="item_title">Pievienot jaunu pozīciju</div>
                <div class="add_button" onclick="show_add_popup();" title="Pievienot jaunu"></div>
            </div>
            <!-- Paraugs
            <div class="item">
                <div class="item_order">#1</div>
                <div class="item_title">Pievienot jaunu pozīciju</div>
                <div class="item_clear"></div>
                <div class="item_content">TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt TExt </div>
                <div class="item_date">13:08 21.01.2019</div>
                <div class="item_orderer">
                    <span>Pārvietot: </span>
                    <div class="item_orderer_up">
                        <img src="media/arr_up.png"/>
                    </div>
                    <div class="item_orderer_down">
                        <img src="media/arr_down.png"/>
                    </div>
                </div>
            </div>
            -->
            <?php
                //Izvelkam visas todo piezīmes
                $i = 1;
                $result = $mysqli->query("SELECT * FROM `".$todo_class->table_name."` WHERE `user_id` = ".$user_id." ORDER BY `order_by` ASC, `todo_id` ASC;");
                if($result)
                while($row = $result->fetch_object()){
            ?>
            <div class="item">
                <div class="item_order"><span>#<?php echo $i; ?></span>
                    <!-- <div class="item_edit_txt">Rediģēt</div> -->
                    <div class="item_edit" onclick="show_edit_popup(this,<?php echo $row->todo_id; ?>);" title="Labot"></div>
                </div>
                <div class="item_title"><?php echo $row->title; ?></div>

                <?php if(!empty($row->contents)){ ?>
                <div class="item_clear"></div>
                <div class="item_content"><?php echo $row->contents; ?></div>
                <?php } ?>

                <div class="item_date"><?php echo $row->created_on; ?></div>
                <div class="item_orderer">
                    <span>Pārvietot: </span>
                    <?php
                        if($i != 1){
                    ?>
                    <div class="item_orderer_up">
                        <img src="media/arr_up.png" onclick="reorder_edit_popup('up', <?php echo $row->todo_id; ?>)"/>
                    </div>
                    <?php
                        };
                        if($i != $result->num_rows){
                    ?>
                    <div class="item_orderer_down">
                        <img src="media/arr_down.png" onclick="reorder_edit_popup('down', <?php echo $row->todo_id; ?>)"/>
                    </div>
                    <?php }; ?>
                </div>
            </div>
            <?php
                $i++;
                } //end while $result->fetch_object
            ?>
        </div>
        <div style="clear:both;"></div>
    </div>
    <script>
        //add
        function show_add_popup(){
            document.getElementById('popup_add').style.display = 'block';
        }
        function hide_add_popup(){
            document.getElementById('popup_add').style.display = 'none';
        }

        //edit
        function show_edit_popup(button, todo_id){
            document.getElementById('popup_edit').style.display = 'block';

            //parnesam piezīmju saturu uz formu
            var parent = button.parentElement.parentElement;
            parent.childNodes.forEach(function (div){
              if(str_has_word(div.className, 'item_title')){
                  document.getElementById('f_edit_todo_title').innerText = div.innerText;
              }
              if(str_has_word(div.className, 'item_content')){
                  document.getElementById('f_edit_todo_text').innerText = div.innerText;
              }
            });

            document.getElementById('f_edit_todo_id').value = todo_id;
        }
        function hide_edit_popup(){
            //on hide clear popup contents!!!!!
            document.getElementById('popup_edit').style.display = 'none';
            document.getElementById('f_edit_todo_title').innerText = '';
            //ne katrai piezīmei ir apraksts (item_content), ne vienmēr vērtības pārrakstās, tapēc izdzešam
            document.getElementById('f_edit_todo_text').innerText = '';
        }
        function delete_edit_popup(){
            var id = document.getElementById('f_edit_todo_id').value;
            //not not a number
            if(!isNaN(id) && id > 0){
                if(confirm("Vai tiešām vēlaties dzēst šo piezīmi?")){
                    self.location = "todo_helper?delete=1&id=" + id;
                }
            }
        }
        //reorder
        function reorder_edit_popup(direction, id){
            var total = document.getElementById('todo').getElementsByClassName('item').length;
            //not not a number
            if(!isNaN(id) && id > 0){
                self.location = "todo_helper?reorder=" + direction + "&id=" + id;
            }
        }

        function str_has_word(string, value){
          if(string == undefined || string == '') return false;
          if(value == undefined || value == '') return false;
          // need spaces between classes, so it wouldn't match parts of class names, but whole
          if( (' '+string+' ').indexOf(' '+value+' ') > -1 ) return true;
        }
    </script>
</body>
</html>
