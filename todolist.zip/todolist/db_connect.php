<?php
if(!defined("asdasdeq1312")) die();

define("MYSQL_HOST","localhost");
define("MYSQL_DB","todo");
define("MYSQL_USER","root");
define("MYSQL_PASS","");
define("MYSQL_PORT",3306);

// $mysqli manīgais tiek izmantot visā projektā, nemainīt
$mysqli = new mysqli(MYSQL_HOST, MYSQL_USER, MYSQL_PASS, MYSQL_DB, MYSQL_PORT);

if($mysqli == false){
    echo ($debug_mode)?"Could not connect to MySQL. Error: ".$mysqli->conncetion_error:"We are sorry, but the site is experiencing technical difficulties.";
}
?>
