<?php   if (!defined("asdasdeq1312")) die();
/* ####   Class Todo   ####
    Create todo list for users. Requires database connection.
    Create, edit, delete, reorder list items from database.
 */

class todo {
    private $user_id;
    private $mysqli;
    private $debug_mode;
    private $max_entries = 1000;// maximums, cik daudz rindiņu var piederēt 1 lietotajam tabulā
    public  $table_name = "todo_list";

    function __construct($mysqli, $user_id, $debug_mode) {
        $this->user_id = (int) $user_id;
        $this->mysqli = $mysqli;
        $this->debug_mode = $debug_mode;

        //pārbaudīt vai eksistē klases tabula
        $result = $mysqli->query("SELECT COUNT(*) as count FROM `information_schema`.`tables` WHERE `table_schema` = '".MYSQL_DB."' AND `table_name` = '".$this->table_name."'; ");
        $tables_found = $result->fetch_object()->count;

        if($tables_found == 0){
            if($debug_mode) echo "</br>Table for class 'todo' does not exist.</br>";
        }
    }

    function create($title, $contents){
        $result = $this->mysqli->query("SELECT COUNT(*) as count FROM `".$this->table_name."` WHERE `user_id` = '".$this->user_id."'; ");
        $rows_found = $result->fetch_object()->count;
        //gadijumā, ja kāds nolemj pārpildīt datubāzi (iespējams to var zidarīt caur `contents`?)
        if($rows_found >= $this->max_entries){
            if($this->debug_mode) echo "</br>User has too many entries.</br>";
        }else{
            $title = $this->mysqli->real_escape_string($title);
            $contents = $this->mysqli->real_escape_string($contents);
            //atrodam lielāko order_by skaitli un pieliekam +1, lai jaunais ir pedējais un nesajūk secība
            $result = $this->mysqli->query("SELECT MAX(`order_by`) as max FROM `".$this->table_name."` WHERE `user_id` = '".$this->user_id."'; ");
            $new_max = $result->fetch_object()->max +1;
            $this->mysqli->query("INSERT into `".$this->table_name."` (`user_id`,`title`,`contents`,`order_by`)
                                    VALUES (".$this->user_id.", '".$title."', '".$contents."', ".$new_max."); ");
        }
    }

    function update($title, $contents, $todo_id){
        $result = $this->mysqli->query("SELECT `user_id` as id FROM `".$this->table_name."` WHERE `todo_id` = ".$todo_id."; ");
        $item_owner = (int) $result->fetch_object()->id;
        // rediģēt var tikai savas piezīmes
        if($item_owner !== $this->user_id && $this->user_id !== null){
            if($this->debug_mode) echo "</br>You aren't owner of this todo item.</br>";
        }else{
            $title = $this->mysqli->real_escape_string($title);
            $contents = $this->mysqli->real_escape_string($contents);
            $this->mysqli->query("UPDATE `".$this->table_name."` SET `user_id`=".$this->user_id.",`title`='".$title."',`contents`='".$contents."' WHERE `todo_id`=".$todo_id."; ");
        }
    }
    function delete($todo_id){
        $result = $this->mysqli->query("SELECT `user_id` as id FROM `".$this->table_name."` WHERE `todo_id` = ".$todo_id."; ");
        $item_owner = (int) $result->fetch_object()->id;
        // dzēst var tikai savas piezīmes
        if($item_owner !== $this->user_id && $this->user_id !== null){
            if($this->debug_mode) echo "</br>You are not owner of this todo item.</br>";
        }else{
            $this->mysqli->query("DELETE FROM `".$this->table_name."` WHERE `todo_id`=".$todo_id."; ");
        }
    }
    function reorder($todo_id, $direction){
        $result = $this->mysqli->query("SELECT `user_id` as id FROM `".$this->table_name."` WHERE `todo_id` = ".$todo_id."; ");
        $item_owner = (int) $result->fetch_object()->id;
        // dzēst var tikai savas piezīmes
        if($item_owner !== $this->user_id && $this->user_id !== null){
            if($this->debug_mode) echo "</br>You're not owner of this todo item.</br>";
        }else{
            $temp_array = []; $i=1; $my_index = '';
            $result = $this->mysqli->query("SELECT `todo_id` as id, `order_by` FROM `".$this->table_name."` WHERE `user_id` = ".$this->user_id." ORDER BY `order_by` ASC, `todo_id` ASC;");
            //saliksim masīvā, kur atslēga ir secība
            if($result)
            while($row = $result->fetch_object()){
                $temp_array[$i]['id'] = $row->id;
                $temp_array[$i]['order'] = $row->order_by;
                if($todo_id == $row->id) $my_index = $i;
                $i++;
            }
            if($my_index == 0){
                if($this->debug_mode) echo "</br>You're not owner of this todo item.</br>";
                return;
            }
            if($direction == 'up' && $my_index > 2){
                $this->mysqli->query("UPDATE `".$this->table_name."` SET `order_by`=".( $temp_array[($my_index-1)]['order'])." WHERE `todo_id`=".$todo_id."; ");
                $this->mysqli->query("UPDATE `".$this->table_name."` SET `order_by`=".$temp_array[$my_index]['order']." WHERE `todo_id`=".$temp_array[($my_index-1)]['id']."; ");
            }
            if($direction == 'down' && isset($temp_array[($my_index+1)])){
                $this->mysqli->query("UPDATE `".$this->table_name."` SET `order_by`=".$temp_array[($my_index+1)]['order']." WHERE `todo_id`=".$todo_id."; ");
                $this->mysqli->query("UPDATE `".$this->table_name."` SET `order_by`=".$temp_array[$my_index]['order']." WHERE `todo_id`=".$temp_array[($my_index+1)]['id']."; ");
            }
            unset($temp_array);
        }
    }
}
?>
